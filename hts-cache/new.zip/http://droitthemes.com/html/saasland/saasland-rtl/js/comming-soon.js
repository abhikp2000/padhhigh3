<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- For Resposive Device -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
	<!-- This site is optimized with the Yoast SEO plugin v15.9 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found | DroitThemes</title>
	<meta name="robots" content="noindex, follow" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found | DroitThemes" />
	<meta property="og:site_name" content="DroitThemes" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://droitthemes.com/#website","url":"https://droitthemes.com/","name":"DroitThemes","description":"Premium quality WordPress themes and web templates for free","potentialAction":[{"@type":"SearchAction","target":"https://droitthemes.com/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.google.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="DroitThemes &raquo; Feed" href="https://droitthemes.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="DroitThemes &raquo; Comments Feed" href="https://droitthemes.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/droitthemes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://droitthemes.com/wp-includes/css/dist/block-library/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='affwp-forms-css'  href='http://droitthemes.com/wp-content/plugins/affiliate-wp/assets/css/forms.min.css?ver=2.6.6' type='text/css' media='all' />
<link rel='stylesheet' id='betterdocs-el-edit-css'  href='http://droitthemes.com/wp-content/plugins/betterdocs/admin/assets/css/betterdocs-el-edit.css?ver=1.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='betterdocs-css'  href='http://droitthemes.com/wp-content/plugins/betterdocs/public/css/betterdocs-public.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='simplebar-css'  href='http://droitthemes.com/wp-content/plugins/betterdocs/public/css/simplebar.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='betterdocs-pro-css'  href='http://droitthemes.com/wp-content/plugins/betterdocs-pro/public/css/betterdocs-pro-public.css?ver=1.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://droitthemes.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.4' type='text/css' media='all' />
<link rel='stylesheet' id='edd-recurring-css'  href='http://droitthemes.com/wp-content/plugins/edd-recurring/assets/css/styles.css?ver=2.9.10' type='text/css' media='all' />
<link rel='stylesheet' id='edd-free-downloads-css'  href='http://droitthemes.com/wp-content/plugins/edd-free-downloads/assets/css/style.min.css?ver=2.3.9' type='text/css' media='all' />
<link rel='stylesheet' id='nxcampaign_mail_settings_css_public-css'  href='http://droitthemes.com/wp-content/plugins/next-mail-development/assets/public/css/public-style.css?ver=1.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='edd_all_access_css-css'  href='http://droitthemes.com/wp-content/plugins/edd-all-access/assets/css/frontend/build/styles.css?ver=1.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='dt-google-fonts-css'  href='http://fonts.googleapis.com/css?display=swap&family=Muli%3A400%2C600%2C700&#038;subset&#038;ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/bootstrap/css/bootstrap.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/magnify-pop/magnific-popup.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-animate-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/animation/animate.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='elegant-icon-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/elegant-icon/style.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-icomoon-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/icomoon-font/style.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='mCustomScrollbar-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/scroll/jquery.mCustomScrollbar.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='sofia-pro-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/fonts/sofiapro.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-wpd-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/css/wpd-style.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-main-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/css/style.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-root-css'  href='http://droitthemes.com/wp-content/themes/dthemes/style.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-responsive-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/css/responsive.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-responsive2-css'  href='http://droitthemes.com/wp-content/themes/dthemes/assets/css/responsive2.css?ver=5.6.2' type='text/css' media='all' />
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/js/jquery.min.js?ver=3.2.1' id='jquery-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/jquery-manager/assets/js/jquery-migrate-3.3.0.min.js' id='jquery-migrate-js'></script>
<script type='text/javascript' id='jquery-cookie-js-extra'>
/* <![CDATA[ */
var affwp_scripts = {"ajaxurl":"https:\/\/droitthemes.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/affiliate-wp/assets/js/jquery.cookie.min.js?ver=1.4.0' id='jquery-cookie-js'></script>
<script type='text/javascript' id='affwp-tracking-js-extra'>
/* <![CDATA[ */
var affwp_debug_vars = {"integrations":{"edd":"Easy Digital Downloads"},"version":"2.6.6","currency":"USD"};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/affiliate-wp/assets/js/tracking.min.js?ver=2.6.6' id='affwp-tracking-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/next-mail-development/assets/public/script/subscribe.js?ver=1.0.1' id='nxcampaign_mail_subscribe-js'></script>
<link rel="https://api.w.org/" href="https://droitthemes.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://droitthemes.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://droitthemes.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.6.2" />
<meta name="framework" content="Redux 4.1.24" />
<style type="text/css" media="all">

</style>
	<style type="text/css">
		.betterdocs-wraper.betterdocs-main-wraper {
						background-color: #ffffff;		
																				}
		.betterdocs-archive-wrap.betterdocs-archive-main {
			padding-top: 50px;
			padding-bottom: 50px;
			padding-left: 0px;
			padding-right: 0px;
		}
		.betterdocs-archive-wrap.betterdocs-archive-main {
			width: 100%;
			max-width: 1600px;
		}
		.betterdocs-categories-wrap.single-kb.layout-masonry .docs-single-cat-wrap {
			margin-bottom: 15px;
		}
		.betterdocs-categories-wrap.single-kb.layout-flex .docs-single-cat-wrap {
			margin: 15px; 
		}
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap .docs-cat-title-wrap { 
			padding-top: 20px; 
		}
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap .docs-cat-title-wrap, 
		.betterdocs-archive-main .docs-item-container { 
			padding-right: 20px;
			padding-left: 20px;  
		}
		.betterdocs-archive-main .docs-item-container { 
			padding-bottom: 20px; 
		}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap,
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap.docs-cat-list-2-box {
			padding-top: 20px; 
			padding-right: 20px;
			padding-left: 20px; 
			padding-bottom: 20px; 
		}
		.betterdocs-categories-wrap.betterdocs-category-box .docs-single-cat-wrap p{
						color: #566e8b;
					}
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap,
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap .docs-cat-title-wrap {
						border-top-left-radius: 5px;
									border-top-right-radius: 5px;
					}
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap,
		.betterdocs-categories-wrap.single-kb .docs-single-cat-wrap .docs-item-container {
						border-bottom-right-radius: 5px;
									border-bottom-left-radius: 5px;
					}
		.betterdocs-category-list .betterdocs-categories-wrap .docs-single-cat-wrap,
		.betterdocs-category-box.white-bg .docs-single-cat-wrap,
		.betterdocs-categories-wrap.white-bg .docs-single-cat-wrap {
						background-color: #fff;
					}
		.betterdocs-category-box.single-kb.ash-bg .docs-single-cat-wrap {
						background-color: #f8f8fc;
					}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap:hover,
		.betterdocs-categories-wrap.single-kb.white-bg .docs-single-cat-wrap.docs-cat-list-2-box:hover {
						background-color: #fff;
					}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap img {
						margin-bottom: 20px;
					}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap .docs-cat-title,
		.pro-layout-4.single-kb .docs-cat-list-2-box-content .docs-cat-title {
						margin-bottom: 15px;
					}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap p {
						margin-bottom: 15px;
					}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap span {
					}
		.docs-cat-title > img { 
			height: 32px; 
		}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap img { 
			height: 80px; 
		}
		.single-kb .docs-cat-title-inner h3,
		.betterdocs-category-box.single-kb .docs-single-cat-wrap .docs-cat-title,
		.single-kb .docs-cat-list-2-box .docs-cat-title,
		.single-kb .docs-cat-list-2-items .docs-cat-title {
			font-size: 20px;
		}
		.docs-cat-title-inner h3 {
			color: #528ffe; 
		}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap .docs-cat-title,
		.single-kb .docs-cat-list-2 .docs-cat-title {
			color: #333333;
		}
				.docs-cat-title-inner {
			border-color: #528ffe; 
		}
		.docs-cat-title-inner span {
			color: #ffffff; 
			font-size: 15px;
		}
		.betterdocs-category-box.single-kb .docs-single-cat-wrap span,
		.single-kb .docs-cat-list-2-box .title-count span {
			color: #707070; 
			font-size: 15px;
		}
		.betterdocs-categories-wrap.single-kb .docs-cat-title-wrap .docs-item-count span {
			font-size: 15px;
		}
		.betterdocs-categories-wrap .docs-item-count {
			background-color: #528ffe; 
		}

		.betterdocs-categories-wrap.single-kb .docs-cat-title-inner span {
			background-color: rgba(82,143,254,0.44);
			width: 30px; 
			height: 30px;
		}
		.betterdocs-categories-wrap.single-kb .docs-item-container {
			background-color: #ffffff;
		}
		.betterdocs-categories-wrap.single-kb .docs-item-container li,
		.betterdocs-categories-wrap.single-kb .docs-item-container .docs-sub-cat-title {
			margin-top: 10px;
			margin-right: 10px;
			margin-bottom: 10px;
			margin-left: 10px;
		}
		.betterdocs-categories-wrap.single-kb .docs-item-container li svg {
			fill: #566e8b;
			font-size: 15px;
		}
		.betterdocs-categories-wrap.single-kb li a {
			color: #566e8b;
			font-size: 15px;
		}
				.betterdocs-categories-wrap.single-kb .docs-item-container .docs-sub-cat li a {
			color: #566e8b;
		}
						.betterdocs-categories-wrap.single-kb .docs-item-container .docs-sub-cat li a:hover {
			color: #566e8b;
		}
						.betterdocs-categories-wrap.single-kb .docs-item-container .docs-sub-cat li svg {
			fill: #566e8b;
		}
				.betterdocs-categories-wrap.single-kb li a:hover {
			color: #566e8b;
		}
		.betterdocs-categories-wrap.single-kb .docs-item-container .docs-sub-cat-title svg {
			fill: #566e8b;
			font-size: 15px;
		}
		.betterdocs-categories-wrap.single-kb .docs-sub-cat-title a {
			color: #566e8b;
			font-size: 17px;
		}
		.betterdocs-categories-wrap.single-kb .docs-sub-cat-title a:hover {
			color: #566e8b;
		}
		.docs-cat-link-btn, .docs-cat-link-btn:visited {
			background-color: #ffffff;
			font-size: 16px;
			color: #528ffe;
			border-color: #528ffe;
			border-top-left-radius: 50px;
			border-top-right-radius: 50px;
			border-bottom-right-radius: 50px;
			border-bottom-left-radius: 50px;
			padding-top: 10px;
			padding-right: 20px;
			padding-bottom: 10px;
			padding-left: 20px;
		}
		.docs-cat-link-btn:hover {
			background-color: #528ffe;
			color: #fff;
			border-color: #528ffe;
		}
		.betterdocs-single-bg .betterdocs-content-area, .betterdocs-single-bg .betterdocs-content-full {
			background-color: ;	
		}
		.betterdocs-single-wraper .betterdocs-content-area {
			padding-top: 30px;
			padding-right: 25px;
			padding-bottom: 30px;
			padding-left: 25px;
		}
		.betterdocs-single-wraper .betterdocs-content-area .docs-single-main {
			padding-top: 20px;
			padding-right: 20px;
			padding-bottom: 20px;
			padding-left: 20px;
		}
		.betterdocs-single-layout2 .docs-content-full-main .doc-single-content-wrapper {
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		.betterdocs-single-layout3 .docs-content-full-main .doc-single-content-wrapper {
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		.docs-single-title .betterdocs-entry-title {
			font-size: 36px;
			color: #3f5876;
		}
		.betterdocs-breadcrumb .betterdocs-breadcrumb-item a {
			font-size: 16px;
			color: #566e8b;
		}
		.betterdocs-breadcrumb .betterdocs-breadcrumb-list .betterdocs-breadcrumb-item a:hover {
			color: #566e8b;
		}
		.betterdocs-breadcrumb .breadcrumb-delimiter {
			color: #566e8b;
		}
		.betterdocs-breadcrumb-item.current span {
			font-size: 16px;
			color: #528fff;
		}
		.betterdocs-toc {
			background-color: #fff;
			padding-top: 20px;
			padding-right: 25px;
			padding-bottom: 20px;
			padding-left: 20px;
		}
		.betterdocs-entry-content .betterdocs-toc {
			margin-bottom: 20px;
		}
		.sticky-toc-container {
			width: 320px;
		}
		.sticky-toc-container.toc-sticky {
			z-index: 2;
			margin-top: 0px;
		}
		.betterdocs-toc > .toc-title {
			color: #3f5876;
			font-size: 18px;
		}
		.betterdocs-entry-content .betterdocs-toc.collapsible-sm .angle-icon {
			color: #3f5876;
		}
		.betterdocs-toc > .toc-list a {
			color: #566e8b;
			font-size: 14px;
			margin-top: 5px;
			margin-right: 0px;
			margin-bottom: 5px;
			margin-left: 0px;
		}
		.betterdocs-toc > .toc-list li a:before {
			font-size: 12px;
			color: #566e8b;
		}
		.betterdocs-toc > .toc-list li:before {
			padding-top: 5px;
		}
		.betterdocs-toc > .toc-list a:hover {
			color: #528fff;
		}
		.feedback-form-link .feedback-form-icon svg, .feedback-form-link .feedback-form-icon img {
			width: 26px;
		}
		.betterdocs-toc > .toc-list a.active {
			color: #528fff;
		}
		.betterdocs-content {
			color: #4d4d4d;
			font-size: 16px;
		}
		.betterdocs-social-share .betterdocs-social-share-heading h5 {
			color: #566e8b;
		}
		.betterdocs-entry-footer .feedback-form-link {
			color: #566e8b;
			font-size: 15px;
		}
		.betterdocs-entry-footer .feedback-update-form .feedback-form-link:hover {
			color: #566e8b;
		}
		.docs-navigation a {
			color: #3f5876;
			font-size: 16px;
		}
		.docs-navigation a:hover {
			color: #3f5876;
		}
		.docs-navigation a svg{
			fill: #5edf8e;
			width: 16px;
		}
		.betterdocs-entry-footer .update-date{
			color: #566e8b;
			font-size: 14px;
		}
		.betterdocs-credit p{
			color: #201d3a;
			font-size: 14px;
		}
		.betterdocs-credit p a{
			color: #528fff;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap,
		.betterdocs-full-sidebar-left {
			background-color: #ffffff;
		}
		.betterdocs-single-layout1 .betterdocs-sidebar-content .betterdocs-categories-wrap {
						border-top-left-radius: 5px;
									border-top-right-radius: 5px;
									border-bottom-right-radius: 5px;
									border-bottom-left-radius: 5px;
					}
		.betterdocs-sidebar-content .docs-single-cat-wrap .docs-cat-title-wrap {
			background-color: #ffffff;
		}
		.betterdocs-sidebar-content .docs-cat-title > img{
			height: 24px;
		}
		.betterdocs-sidebar-content .docs-cat-title-inner h3{
			color: #3f5876;
			font-size: 16px;
		}
		.betterdocs-sidebar-content .docs-cat-title-inner h3:hover {
			color: #3f5876 !important;
		}
		.betterdocs-sidebar-content .docs-cat-title-inner .cat-list-arrow-down {
			color: #3f5876;
		}
		.betterdocs-sidebar-content .docs-single-cat-wrap .active-title .docs-cat-title-inner h3,
		.betterdocs-sidebar-content .active-title .docs-cat-title-inner h3,
		.betterdocs-full-sidebar-left .docs-cat-title-wrap::after {
			color: #3f5876;
		}
		.betterdocs-sidebar-content .docs-item-count {
			background-color: #528ffe;
		}
		.betterdocs-sidebar-content .docs-item-count span {
			background-color: rgba(82, 143, 255, 0.2);
			color: #ffffff;
			font-size: 12px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap .docs-single-cat-wrap {
			margin-top: 5px;
			margin-right: 0px;
			margin-bottom: 5px;
			margin-left: 0px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap, .betterdocs-full-sidebar-left .betterdocs-categories-wrap {
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap .docs-single-cat-wrap .docs-cat-title-wrap {
			padding-top: 10px;
			padding-right: 15px;
			padding-bottom: 10px;
			padding-left: 15px;
		}
		.betterdocs-single-layout2 .betterdocs-full-sidebar-left .betterdocs-sidebar-content .betterdocs-categories-wrap .docs-cat-title-inner {
						background-color: #ffffff;		
						padding-top: 10px;
			padding-right: 15px;
			padding-bottom: 10px;
			padding-left: 15px;
		}
		.betterdocs-sidebar-content .docs-item-container{
			background-color: #ffffff;
		}
		.betterdocs-sidebar-content .docs-single-cat-wrap .docs-cat-title-wrap.active-title{
			background-color: rgba(90, 148, 255, .1);
			border-color: #528fff;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap .docs-item-container li {
			padding-left: 0;
			margin-top: 10px;
			margin-right: 10px;
			margin-bottom: 10px;
			margin-left: 10px;
		}
		.betterdocs-single-layout2 .betterdocs-sidebar-content .betterdocs-categories-wrap .docs-item-container li {
			margin-right: 0 !important;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li a {
			color: #566e8b;
			font-size: 14px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li a:hover {
			color: #528fff;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li svg {
			fill: #566e8b;
			font-size: 14px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li a.active,
		.betterdocs-sidebar-content .betterdocs-categories-wrap li.sub-list a.active {
			color: #528fff;
		}	
		.betterdocs-category-wraper.betterdocs-single-wraper{
																				}	
		.betterdocs-category-wraper.betterdocs-single-wraper .docs-listing-main .docs-category-listing{
						background-color: #ffffff;
						margin-top: 0px;
			margin-right: 0px;
			margin-bottom: 0px;
			margin-left: 0px;
			padding-top: 30px;
			padding-right: 30px;
			padding-bottom: 30px;
			padding-left: 30px;
			border-radius: 5px;
		}
		.betterdocs-category-wraper .docs-category-listing .docs-cat-title h3 {
			color: #566e8b;
			font-size: 20px;
			margin-top: 0px;
			margin-right: 0px;
			margin-bottom: 20px;
			margin-left: 0px;
		}
		.betterdocs-category-wraper .docs-category-listing .docs-cat-title p {
			color: #566e8b;
			font-size: 14px;
			margin-top: 0px;
			margin-right: 0px;
			margin-bottom: 20px;
			margin-left: 0px;
		}
		.docs-category-listing .docs-list ul li, 
		.docs-category-listing .docs-list .docs-sub-cat-title {
			margin-top: 10px;
			margin-right: 0px;
			margin-bottom: 10px;
			margin-left: 0px;
		}
		.docs-category-listing .docs-list ul li svg {
			fill: #566e8b;
			font-size: 16px;
		}
		.docs-category-listing .docs-list ul li a {
			color: #566e8b;
			font-size: 14px;
		}
		.docs-category-listing .docs-list ul li a:hover {
			color: #528ffe;
		}
				.docs-category-listing .docs-list .docs-sub-cat li a {
			color: #566e8b;
		}
						.docs-category-listing .docs-list .docs-sub-cat li a:hover {
			color: #566e8b;
		}
						.docs-category-listing .docs-list .docs-sub-cat li svg {
			fill: #566e8b;
		}
				.docs-category-listing .docs-list .docs-sub-cat-title svg {
			fill: #566e8b;
			font-size: 15px;
		}
		.docs-category-listing .docs-list .docs-sub-cat-title a {
			color: #566e8b;
			font-size: 17px;
		}
		.docs-category-listing .docs-list .docs-sub-cat-title a:hover {
			color: #566e8b;
		}

		.betterdocs-search-form-wrap{
						background-color: #f7f7f7;
																					padding-top: 100px;
			padding-right: 20px;
			padding-bottom: 50px;
			padding-left: 20px;
		}
		.betterdocs-search-heading h2 {
			line-height: 1.2;
			font-size: 40px;
			color: #566e8b;
			margin-top: 0px;
			margin-right: 0px;
			margin-bottom: 20px;
			margin-left: 0px;
		}
		.betterdocs-search-heading h3 {
			line-height: 1.2;
			font-size: 16px;
			color: #566e8b;
			margin-top: 0px;
			margin-right: 0px;
			margin-bottom: 20px;
			margin-left: 0px;
		}
		.betterdocs-searchform {
			background-color: #ffffff;
			border-radius: 8px;
			padding-top: 22px;
			padding-right: 15px;
			padding-bottom: 22px;
			padding-left: 15px;
		}
		.betterdocs-searchform .betterdocs-search-field{
			font-size: 18px;
			color: #595959;
		}
		.betterdocs-searchform svg.docs-search-icon {
			fill: #444b54;
			height: 30px;
		}
		.docs-search-close path.close-line {
			fill: #ff697b;	
		}
		.docs-search-close path.close-border {
			fill: #444b54;	
		}
		.docs-search-loader {
			stroke: #444b54;	
		}
		.betterdocs-searchform svg.docs-search-icon:hover {
			fill: #444b54;
		}
		.betterdocs-live-search .docs-search-result {
			width: 100%;
			max-width: 800px;
			background-color: #fff;
			border-color: #f1f1f1;
		}
		.betterdocs-search-result-wrap::before {
			border-color: transparent transparent #fff;
		}
		.betterdocs-live-search .docs-search-result li {
			border-color: #f5f5f5;
		}
		.betterdocs-live-search .docs-search-result li a {
			font-size: 16px;
			color: #444444;
			padding-top: 10px;
			padding-right: 10px;
			padding-bottom: 10px;
			padding-left: 10px;
		}
		.betterdocs-live-search .docs-search-result li:only-child {
			font-size: 16px;
			color: #444444;
		}
		.betterdocs-live-search .docs-search-result li:hover {
			background-color: #f5f5f5;
		}
		.betterdocs-live-search .docs-search-result li a:hover {
			color: #444444;
		}
		.betterdocs-category-box.pro-layout-3 .docs-single-cat-wrap img,
		.docs-cat-list-2-box img {
			margin-right: 20px;
		}
		.betterdocs-wraper .betterdocs-search-form-wrap.cat-layout-4 {
			padding-bottom: 130px;
		}
	</style>
	<script>
		jQuery(document).ready(function() {
			var masonryGrid = jQuery(".betterdocs-categories-wrap.layout-masonry");
			var columnPerGrid = jQuery(".betterdocs-categories-wrap.layout-masonry").attr('data-column');
			var masonryItem = jQuery(".betterdocs-categories-wrap.layout-masonry .docs-single-cat-wrap");
			var doc_page_column_space = 15;
			var total_margin = columnPerGrid * doc_page_column_space;
			if (masonryGrid.length) {
				masonryItem.css("width", "calc((100% - "+total_margin+"px) / "+parseInt(columnPerGrid)+")");
				masonryGrid.masonry({
					itemSelector: ".docs-single-cat-wrap",
					percentPosition: true,
					gutter: doc_page_column_space
				});
			}
		});
	</script>
    	<style type="text/css">
		
		.docs-cat-list-2-items .docs-cat-title {
			font-size: 18px;
		}
		.betterdocs-category-box.pro-layout-3 .docs-single-cat-wrap img,
		.docs-cat-list-2-box img {
						height: 60px;
						width: auto;
			margin-bottom: 0px !important;
		}
				.betterdocs-article-reactions .betterdocs-article-reactions-heading h5 {
			color: #566e8b;
		}
		.betterdocs-article-reaction-links li a {
			background-color: #00b88a;
		}
		.betterdocs-article-reaction-links li a:hover {
			background-color: #fff;
		}
		.betterdocs-article-reaction-links li a svg path {
			fill: #fff;
		}
		.betterdocs-article-reaction-links li a:hover svg path {
			fill: #00b88a;
		}
	</style>
    <meta name="generator" content="Easy Digital Downloads v2.9.26" />
		<script type="text/javascript">
		var AFFWP = AFFWP || {};
		AFFWP.referral_var = 'ref';
		AFFWP.expiration = 1;
		AFFWP.debug = 0;


		AFFWP.referral_credit_last = 0;
		</script>
<link rel="icon" href="https://droitthemes.com/wp-content/uploads/2020/06/small_logo.png" sizes="32x32" />
<link rel="icon" href="https://droitthemes.com/wp-content/uploads/2020/06/small_logo.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://droitthemes.com/wp-content/uploads/2020/06/small_logo.png" />
<meta name="msapplication-TileImage" content="https://droitthemes.com/wp-content/uploads/2020/06/small_logo.png" />
		<style type="text/css" id="wp-custom-css">
			.vriation_images .elementor-image img{
	box-shadow: 0px 3px 4px 0px rgba(0, 0, 0, 0.1) !important;
    margin: 0px 49px 0px 0px;
    padding: 0px 0px 0px 0px;
}

.vriation_images .elementor-image img:hover{
	box-shadow: 0 24px 50px 0 rgba(0,0,0,.1) !important;
}
.mailpoet_form_image img{
	max-width: 100%;
}
		</style>
		<!-- LeadFeader Email Marketing -->	
	
	<script> (function(){ window.ldfdr = window.ldfdr || {}; (function(d, s, ss, fs){ fs = d.getElementsByTagName(s)[0]; function ce(src){ var cs = d.createElement(s); cs.src = src; setTimeout(function(){fs.parentNode.insertBefore(cs,fs)}, 1); } ce(ss); })(document, 'script', 'https://sc.lfeeder.com/lftracker_v1_lAxoEaKRprA4OYGd.js'); })(); </script>
	
<!-- End -->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WSPSVG7');</script>
<!-- End Google Tag Manager -->
	
</head>

<body class="error404 wp-embed-responsive not_logged_in elementor-default elementor-kit-3536" data-spy="scroll" data-target=".navbar" data-offset="70">
	
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WSPSVG7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
	
<!-- offer Modal -->
   
<!-- offer Modal end-->	

    <nav class="navbar navbar-expand-lg header_area" id="sticky">
        <div class="container">
            <div class="logo_wrapper">
    <a class="navbar-brand" href="https://droitthemes.com/">
                <img src="https://droitthemes.com/wp-content/themes/dthemes/assets/img/logo.png" srcset='https://droitthemes.com/wp-content/themes/dthemes/assets/img/logo@2x.png 2x' alt="DroitThemes">
    </a>
</div>                            <a class="theme_btn menu_btn ml-auto d-lg-none" href="#" data-toggle="modal" data-target="#login-modal">
                    Join/Login                </a>
                        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu_toggle">
                    <span class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                    <span class="hamburger-cross">
                        <span></span>
                        <span></span>
                    </span>
                </span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul id="menu-main-menu" class="navbar-nav ml-auto menu"><li itemscope="itemscope"  id="menu-item-16260" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16260 nav-item"><a title="Droit Addons" class="nav-link" href="https://droitthemes.com/droit-elementor-addons/">Droit Addons&nbsp;</a></li>
<li itemscope="itemscope"  id="menu-item-3524" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3524 nav-item"><a title="WP Themes" class="nav-link" href="https://droitthemes.com/wordpress-themes/">WP Themes&nbsp;</a></li>
<li itemscope="itemscope"  id="menu-item-3523" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3523 nav-item"><a title="HTML" class="nav-link" href="https://droitthemes.com/html-templates/">HTML&nbsp;</a></li>
<li itemscope="itemscope"  id="menu-item-16261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16261 nav-item"><a title="PSD" class="nav-link" href="https://droitthemes.com/psd-template/">PSD&nbsp;</a></li>
<li itemscope="itemscope"  id="menu-item-3532" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-3532 nav-item"><a title="Blog" class="nav-link" href="https://droitthemes.com/blog/">Blog&nbsp;</a></li>
</ul>                    <a class="theme_btn menu_btn btn_none" href="#" data-toggle="modal" data-target="#signup-modal">
                        Join/Login                    </a>
                                            </div>
        </div>
    </nav>

    
<section class="blog_area theme_banner">
    <img class="position-absolute image_two" src="http://droitthemes.com/wp-content/themes/dthemes/assets/img//blog/blog_banner_icon1.png" alt="pen paper writing icon">
    <img class="position-absolute image_three" src="http://droitthemes.com/wp-content/themes/dthemes/assets/img//blog/blog_banner_icon2.png" alt="WordPress icon png">
    <img class="position-absolute image_four" src="http://droitthemes.com/wp-content/themes/dthemes/assets/img//blog/blog_banner_icon3.png" alt="newspaper icon">
    <div class="container">
        <div class="theme_details_title theme_details_title_two text-center">
            <h1 class="wow fadeInUp">Neat Tricks and Tips to Improve Macbook’s Performance</h1>
                    </div>
        <div class="row">
            <div class="col-lg-8">
                                        <div class="blog_post_item post-2570 post type-post status-publish format-standard has-post-thumbnail hentry category-wordpress-theme tag-multipurpose-wordpress-theme tag-saasland">
                            <a href="https://droitthemes.com/saasland-the-best-multipurpose-wordpress-theme-for-agencies-startups/" class="post_img">
                                <img width="1200" height="675" src="https://droitthemes.com/wp-content/uploads/2019/11/Saasland-dark-feature-image.jpg" class="attachment-dt_730x450 size-dt_730x450 wp-post-image" alt="Saasland dark feature image" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/2019/11/Saasland-dark-feature-image.jpg 1200w, https://droitthemes.com/wp-content/uploads/2019/11/Saasland-dark-feature-image-300x169.jpg 300w, https://droitthemes.com/wp-content/uploads/2019/11/Saasland-dark-feature-image-1024x576.jpg 1024w, https://droitthemes.com/wp-content/uploads/2019/11/Saasland-dark-feature-image-768x432.jpg 768w" sizes="(max-width: 1200px) 100vw, 1200px" />                            </a>
                            <div class="blog_content">
                                <div class="post_info">
                                    <a href="https://droitthemes.com/author/dlab3/">
                                        <i class="icon-author"></i>Md Shahadat Hussain                                    </a>
                                    <a href="https://droitthemes.com/2019/11/10/"><i class="icon-calendar"></i>November 10, 2019</a>
                                    <a href="https://droitthemes.com/saasland-the-best-multipurpose-wordpress-theme-for-agencies-startups/#comments"><i class="icon-comments"></i>3 Comments</a>
                                </div>
                                <a href="https://droitthemes.com/saasland-the-best-multipurpose-wordpress-theme-for-agencies-startups/">
                                    <h2>Saasland – The Best Multipurpose WordPress Theme for Agencies &#038; Startups</h2>
                                </a>
                                Saasland is a creative WordPress theme for saas, software, startup, mobile app, agency and related products &amp; services. If you are planning on launching a startup, or an agency looking forward to building a website? Then we have some news for you. Looking for a proper theme that fits your requirement could be frustrating!&nbsp;And the&hellip;                                <!--<a href="" class="arrow_btn">Read More <i class="icon-arrow-right-2"></i></a>-->
                            </div>
                        </div>
                                    
                <div class="row">
                                            <div class="col-sm-6">
                            <div class="blog_post_item small_post">
                                <a href="https://droitthemes.com/neat-tricks-and-tips-to-improve-macbooks-performance/" class="post_img">
                                    <img width="350" height="215" src="https://droitthemes.com/wp-content/uploads/2021/01/improve-macbooks-performance-350x215.jpg" class="attachment-dt_350x215 size-dt_350x215 wp-post-image" alt="improve-macbooks-performance" loading="lazy" />                                </a>
                                <div class="blog_content">
                                    <div class="post_info">
                                        <a href="https://droitthemes.com/2021/01/26/">
                                            <i class="icon-author"></i>DroitThemes                                        </a>
                                        <a href="https://droitthemes.com/2021/01/26/">
                                            <i class="icon-calendar"></i>January 26, 2021                                        </a>
                                    </div>
                                    <a href="https://droitthemes.com/neat-tricks-and-tips-to-improve-macbooks-performance/">
                                        <h2>Neat Tricks and Tips to Improve Macbook’s Performance</h2>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                <div class="col-sm-6">
                            <div class="blog_post_item small_post">
                                <a href="https://droitthemes.com/how-to-protect-yourself-from-malware/" class="post_img">
                                    <img width="350" height="215" src="https://droitthemes.com/wp-content/uploads/2020/12/Protect-Yourself-from-Malware-350x215.png" class="attachment-dt_350x215 size-dt_350x215 wp-post-image" alt="Protect Yourself from Malware" loading="lazy" />                                </a>
                                <div class="blog_content">
                                    <div class="post_info">
                                        <a href="https://droitthemes.com/2020/12/10/">
                                            <i class="icon-author"></i>Enaan Farhan                                        </a>
                                        <a href="https://droitthemes.com/2020/12/10/">
                                            <i class="icon-calendar"></i>December 10, 2020                                        </a>
                                    </div>
                                    <a href="https://droitthemes.com/how-to-protect-yourself-from-malware/">
                                        <h2>How to Protect Yourself from Malware in the Covid Era</h2>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                <div class="col-sm-6">
                            <div class="blog_post_item small_post">
                                <a href="https://droitthemes.com/why-and-how-to-build-a-website-as-an-influencer/" class="post_img">
                                    <img width="350" height="215" src="https://droitthemes.com/wp-content/uploads/2020/12/Build-a-Website-as-an-Influencer-350x215.png" class="attachment-dt_350x215 size-dt_350x215 wp-post-image" alt="Build a Website as an Influencer" loading="lazy" />                                </a>
                                <div class="blog_content">
                                    <div class="post_info">
                                        <a href="https://droitthemes.com/2020/12/06/">
                                            <i class="icon-author"></i>Nafees Kausar                                        </a>
                                        <a href="https://droitthemes.com/2020/12/06/">
                                            <i class="icon-calendar"></i>December 6, 2020                                        </a>
                                    </div>
                                    <a href="https://droitthemes.com/why-and-how-to-build-a-website-as-an-influencer/">
                                        <h2>Why and How to Build a Website as an Influencer</h2>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                <div class="col-sm-6">
                            <div class="blog_post_item small_post">
                                <a href="https://droitthemes.com/4-things-you-need-to-build-an-effective-web-presence/" class="post_img">
                                    <img width="350" height="215" src="https://droitthemes.com/wp-content/uploads/2020/11/4-Things-You-Need-to-Build-an-Effective-Web-Presence-350x215.png" class="attachment-dt_350x215 size-dt_350x215 wp-post-image" alt="4 Things You Need to Build an Effective Web Presence" loading="lazy" />                                </a>
                                <div class="blog_content">
                                    <div class="post_info">
                                        <a href="https://droitthemes.com/2020/11/24/">
                                            <i class="icon-author"></i>Md Shahadat Hussain                                        </a>
                                        <a href="https://droitthemes.com/2020/11/24/">
                                            <i class="icon-calendar"></i>November 24, 2020                                        </a>
                                    </div>
                                    <a href="https://droitthemes.com/4-things-you-need-to-build-an-effective-web-presence/">
                                        <h2>4 Things You Need to Build an Effective Web Presence</h2>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                <div class="col-sm-6">
                            <div class="blog_post_item small_post">
                                <a href="https://droitthemes.com/10-best-ecommerce-platforms/" class="post_img">
                                    <img width="350" height="215" src="https://droitthemes.com/wp-content/uploads/2020/10/Best-Ecommerce-Platforms-350x215.png" class="attachment-dt_350x215 size-dt_350x215 wp-post-image" alt="Best Ecommerce Platforms" loading="lazy" />                                </a>
                                <div class="blog_content">
                                    <div class="post_info">
                                        <a href="https://droitthemes.com/2020/11/23/">
                                            <i class="icon-author"></i>Md Shahadat Hussain                                        </a>
                                        <a href="https://droitthemes.com/2020/11/23/">
                                            <i class="icon-calendar"></i>November 23, 2020                                        </a>
                                    </div>
                                    <a href="https://droitthemes.com/10-best-ecommerce-platforms/">
                                        <h2>9+ Best Ecommerce Platforms for 2021</h2>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                <div class="col-sm-6">
                            <div class="blog_post_item small_post">
                                <a href="https://droitthemes.com/discord-vs-slack-vs-teams/" class="post_img">
                                    <img width="350" height="215" src="https://droitthemes.com/wp-content/uploads/2020/11/Discord-vs-Slack-vs-MS-Teams-350x215.png" class="attachment-dt_350x215 size-dt_350x215 wp-post-image" alt="Discord vs Slack vs MS Teams" loading="lazy" />                                </a>
                                <div class="blog_content">
                                    <div class="post_info">
                                        <a href="https://droitthemes.com/2020/11/22/">
                                            <i class="icon-author"></i>Md Shahadat Hussain                                        </a>
                                        <a href="https://droitthemes.com/2020/11/22/">
                                            <i class="icon-calendar"></i>November 22, 2020                                        </a>
                                    </div>
                                    <a href="https://droitthemes.com/discord-vs-slack-vs-teams/">
                                        <h2>Discord vs Slack vs MS Teams: The Best Choice for Your Team</h2>
                                    </a>
                                </div>
                            </div>
                        </div>
                                        </div>
                <nav class="navigation pagination justify-content-center">
                    
	<nav class="navigation pagination" role="navigation" aria-label="Posts">
		<h2 class="screen-reader-text">Posts navigation</h2>
		<div class="nav-links"><span aria-current="page" class="page-numbers current">1</span>
<a class="page-numbers" href="https://droitthemes.com/html/saasland/saasland-rtl/js/comming-soon.js/page/2/">2</a>
<span class="page-numbers dots">&hellip;</span>
<a class="page-numbers" href="https://droitthemes.com/html/saasland/saasland-rtl/js/comming-soon.js/page/19/">19</a>
<a class="next page-numbers" href="https://droitthemes.com/html/saasland/saasland-rtl/js/comming-soon.js/page/2/"><i class="icon-arrow-right-2"></i></a></div>
	</nav>                </nav>
                            </div>

            
<div class="col-lg-4">
    <div class="blog_sidebar">
        <div id="search-2" class="widget sidebar_widget widget_search"><form action="https://droitthemes.com/" class="search-form input-group">
                <input type="search" name="s" class="form-control" placeholder="Search" value="">
                <span class="input-group-addon"><button type="submit"><i class="ti-search"></i></button></span>
             </form></div><div id="custom_html-3" class="widget_text widget sidebar_widget widget_custom_html"><div class="textwidget custom-html-widget"><a href="https://droitthemes.com/go/saasland" target="_blank" rel="noopener"><img src="https://droitthemes.com/wp-content/uploads/2020/12/Saasland-widget-ad.jpg" alt="Saasland - #1 selling wordpress theme"></a></div></div>      <div id="mailpoet_form-2" class="widget sidebar_widget widget_mailpoet_form">
  
  
  <div class="
    mailpoet_form_popup_overlay
      "></div>
  <div
    id="mailpoet_form_6"
    class="
      mailpoet_form
      mailpoet_form_widget
      mailpoet_form_position_
      mailpoet_form_animation_
    "
      >
    
    <style type="text/css">
     .mailpoet_hp_email_label{display:none!important;}#mailpoet_form_6 .mailpoet_form {  }
#mailpoet_form_6 form { margin-bottom: 0; }
#mailpoet_form_6 ::placeholder { color: black; }
#mailpoet_form_6 .mailpoet_column_with_background { padding: 0px; }
#mailpoet_form_6 .wp-block-column:not(:first-child), #mailpoet_form_6 .mailpoet_form_column:not(:first-child) { padding: 0 20px; }
#mailpoet_form_6 .mailpoet_form_column:not(:first-child) { margin-left: 0; }
#mailpoet_form_6 h2.mailpoet-heading { margin: 0 0 20px 0; }
#mailpoet_form_6 .mailpoet_paragraph { line-height: 20px; margin-bottom: 20px; }
#mailpoet_form_6 .mailpoet_segment_label, #mailpoet_form_6 .mailpoet_text_label, #mailpoet_form_6 .mailpoet_textarea_label, #mailpoet_form_6 .mailpoet_select_label, #mailpoet_form_6 .mailpoet_radio_label, #mailpoet_form_6 .mailpoet_checkbox_label, #mailpoet_form_6 .mailpoet_list_label, #mailpoet_form_6 .mailpoet_date_label { display: block; font-weight: normal; }
#mailpoet_form_6 .mailpoet_text, #mailpoet_form_6 .mailpoet_textarea, #mailpoet_form_6 .mailpoet_select, #mailpoet_form_6 .mailpoet_date_month, #mailpoet_form_6 .mailpoet_date_day, #mailpoet_form_6 .mailpoet_date_year, #mailpoet_form_6 .mailpoet_date { display: block; }
#mailpoet_form_6 .mailpoet_text, #mailpoet_form_6 .mailpoet_textarea { width: 200px; }
#mailpoet_form_6 .mailpoet_checkbox {  }
#mailpoet_form_6 .mailpoet_submit {  }
#mailpoet_form_6 .mailpoet_divider {  }
#mailpoet_form_6 .mailpoet_message {  }
#mailpoet_form_6 .mailpoet_form_loading { width: 30px; text-align: center; line-height: normal; }
#mailpoet_form_6 .mailpoet_form_loading &gt; span { width: 5px; height: 5px; background-color: #5b5b5b; }#mailpoet_form_6{border: 0px solid #f3f4f9;border-radius: 0px;color: #1e1e1e;text-align: center;}#mailpoet_form_6 form.mailpoet_form {padding: 0px;}#mailpoet_form_6{width: 100%;}#mailpoet_form_6 .mailpoet_message {margin: 0; padding: 0 20px;}
        #mailpoet_form_6 .mailpoet_validate_success {color: #000000}
        #mailpoet_form_6 input.parsley-success {color: #000000}
        #mailpoet_form_6 select.parsley-success {color: #000000}
        #mailpoet_form_6 textarea.parsley-success {color: #000000}
      
        #mailpoet_form_6 .mailpoet_validate_error {color: #cf2e2e}
        #mailpoet_form_6 input.parsley-error {color: #cf2e2e}
        #mailpoet_form_6 select.parsley-error {color: #cf2e2e}
        #mailpoet_form_6 textarea.textarea.parsley-error {color: #cf2e2e}
        #mailpoet_form_6 .parsley-errors-list {color: #cf2e2e}
        #mailpoet_form_6 .parsley-required {color: #cf2e2e}
        #mailpoet_form_6 .parsley-custom-error-message {color: #cf2e2e}
      #mailpoet_form_6 .mailpoet_paragraph.last {margin-bottom: 0} @media (max-width: 500px) {#mailpoet_form_6 {background-image: none;}} @media (min-width: 500px) {#mailpoet_form_6 .last .mailpoet_paragraph:last-child {margin-bottom: 0}}  @media (max-width: 500px) {#mailpoet_form_6 .mailpoet_form_column:last-child .mailpoet_paragraph:last-child {margin-bottom: 0}} 
    </style>

    <form
      target="_self"
      method="post"
      action="https://droitthemes.com/wp-admin/admin-post.php?action=mailpoet_subscription_form"
      class="mailpoet_form mailpoet_form_form mailpoet_form_widget"
      novalidate
      data-delay=""
      data-exit-intent-enabled=""
      data-font-family=""
    >
      <input type="hidden" name="data[form_id]" value="6" />
      <input type="hidden" name="token" value="281e726c83" />
      <input type="hidden" name="api_version" value="v1" />
      <input type="hidden" name="endpoint" value="subscribers" />
      <input type="hidden" name="mailpoet_method" value="subscribe" />

      <label class="mailpoet_hp_email_label">Please leave this field empty<input type="email" name="data[email]"/></label><div class="mailpoet_form_columns mailpoet_paragraph mailpoet_vertically_align_top has-#000000-color" style="color:#000000;background:;"><div class="mailpoet_form_column mailpoet_vertically_align_top" style="flex-basis:50%;"><div class='mailpoet_spacer' style='height: 1px;'></div>
<p class="mailpoet_form_paragraph  mailpoet-has-font-size" style="text-align: left; font-size: 25px"><strong>Subscribe</strong> and <strong>get free gifts!</strong></p>
<p class="mailpoet_form_paragraph  mailpoet-has-font-size" style="text-align: left; color: #1e1e1e; font-size: 17px"><span style="font-family: Cairo" data-font="Cairo" class="mailpoet-has-font">Get free <strong><span style="color:#3a69f3" class="has-inline-color">WordPress plugins &amp; themes</span></strong></span>, great tips &amp; tricks of web development and more, delivered to you on a platter.</p>
<div class="mailpoet_paragraph "><style>input[name="data[form_field_ZTQ4MGU4NTJlOTI5X2ZpcnN0X25hbWU=]"]::placeholder{color:#000000;opacity: 1;}</style><input type="text" class="mailpoet_text" name="data[form_field_ZTQ4MGU4NTJlOTI5X2ZpcnN0X25hbWU=]" title="Full Name" value="" style="width:100%;background-color:#f3f4f9;border-style:solid;border-radius:5px !important;border-width:0px;border-color:#f3f4f9;padding:15px;margin: 0 auto;font-family:&#039;Cairo&#039;;font-size:15px;line-height:1.5;height:auto;color:#000000;" data-automation-id="form_first_name"  placeholder="Full Name" data-parsley-pattern="^[^><]*$" data-parsley-error-message="Please specify a valid name"/></div>
<div class="mailpoet_paragraph "><style>input[name="data[form_field_NDU3YTE0OWFhNDI3X2VtYWls]"]::placeholder{color:#000000;opacity: 1;}</style><input type="email" class="mailpoet_text" name="data[form_field_NDU3YTE0OWFhNDI3X2VtYWls]" title="Email Address" value="" style="width:100%;background-color:#f3f4f9;border-style:solid;border-radius:5px !important;border-width:0px;border-color:#f3f4f9;padding:15px;margin: 0 auto;font-family:&#039;Cairo&#039;;font-size:15px;line-height:1.5;height:auto;color:#000000;" data-automation-id="form_email"  placeholder="Email Address *" data-parsley-required="true" data-parsley-minlength="6" data-parsley-maxlength="150" data-parsley-error-message="Please specify a valid email address." data-parsley-required-message="This field is required."/></div>
<div class="mailpoet_paragraph "><input type="submit" class="mailpoet_submit" value="Get Happiness" data-automation-id="subscribe-submit-button" data-font-family='Cairo' style="width:100%;background-color:#3a69f3;border-style:solid;border-radius:5px !important;border-width:0px;border-color:#313131;padding:14px;margin: 0 auto;font-family:&#039;Cairo&#039;;font-size:15px;line-height:1.5;height:auto;color:#ffffff;font-weight:bold;" /><span class="mailpoet_form_loading"><span class="mailpoet_bounce1"></span><span class="mailpoet_bounce2"></span><span class="mailpoet_bounce3"></span></span></div>
<p class="mailpoet_form_paragraph  mailpoet-has-font-size" style="text-align: center; color: #1e1e1e; font-size: 12px"><span style="font-family: Cairo" data-font="Cairo" class="mailpoet-has-font">We will not spam you. Promise!</span></p>
</div>
</div>

      <div class="mailpoet_message">
        <p class="mailpoet_validate_success"
                style="display:none;"
                >Check your inbox or spam folder to confirm your subscription.
        </p>
        <p class="mailpoet_validate_error"
                style="display:none;"
                >        </p>
      </div>
    </form>
  </div>

      </div>
  <div id="recent-posts-2" class="widget sidebar_widget recent_post_widget"><h3 class="widget_title">Recent Posts</h3>             <div class="media post_item post-16517 post type-post status-publish format-standard has-post-thumbnail hentry category-droitthemes tag-macbook">
                <a href="https://droitthemes.com/neat-tricks-and-tips-to-improve-macbooks-performance/">
                    <img width="85" height="70" src="https://droitthemes.com/wp-content/uploads/2021/01/improve-macbooks-performance-85x70.jpg" class="media-object wp-post-image" alt="improve-macbooks-performance" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/2021/01/improve-macbooks-performance-85x70.jpg 85w, https://droitthemes.com/wp-content/uploads/2021/01/improve-macbooks-performance-540x450.jpg 540w" sizes="(max-width: 85px) 100vw, 85px" />                </a>
                <div class="media-body">
                    <a href="https://droitthemes.com/neat-tricks-and-tips-to-improve-macbooks-performance/" title="Neat Tricks and Tips to Improve Macbook’s Performance">
                        <h5> Neat Tricks and Tips to Improve... </h5>
                    </a>
                                            <a class="entry_post_info" href="https://droitthemes.com/2021/01/26/">
                            January 26, 2021                        </a>
                                    </div>
            </div>
                    <div class="media post_item post-16517 post type-post status-publish format-standard has-post-thumbnail hentry category-droitthemes tag-macbook">
                <a href="https://droitthemes.com/how-to-protect-yourself-from-malware/">
                    <img width="85" height="70" src="https://droitthemes.com/wp-content/uploads/2020/12/Protect-Yourself-from-Malware-85x70.png" class="media-object wp-post-image" alt="Protect Yourself from Malware" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/2020/12/Protect-Yourself-from-Malware-85x70.png 85w, https://droitthemes.com/wp-content/uploads/2020/12/Protect-Yourself-from-Malware-540x450.png 540w" sizes="(max-width: 85px) 100vw, 85px" />                </a>
                <div class="media-body">
                    <a href="https://droitthemes.com/how-to-protect-yourself-from-malware/" title="How to Protect Yourself from Malware in the Covid Era">
                        <h5> How to Protect Yourself from Malware... </h5>
                    </a>
                                            <a class="entry_post_info" href="https://droitthemes.com/2021/01/26/">
                            December 10, 2020                        </a>
                                    </div>
            </div>
                    <div class="media post_item post-16517 post type-post status-publish format-standard has-post-thumbnail hentry category-droitthemes tag-macbook">
                <a href="https://droitthemes.com/why-and-how-to-build-a-website-as-an-influencer/">
                    <img width="85" height="70" src="https://droitthemes.com/wp-content/uploads/2020/12/Build-a-Website-as-an-Influencer-85x70.png" class="media-object wp-post-image" alt="Build a Website as an Influencer" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/2020/12/Build-a-Website-as-an-Influencer-85x70.png 85w, https://droitthemes.com/wp-content/uploads/2020/12/Build-a-Website-as-an-Influencer-540x450.png 540w" sizes="(max-width: 85px) 100vw, 85px" />                </a>
                <div class="media-body">
                    <a href="https://droitthemes.com/why-and-how-to-build-a-website-as-an-influencer/" title="Why and How to Build a Website as an Influencer">
                        <h5> Why and How to Build a... </h5>
                    </a>
                                            <a class="entry_post_info" href="https://droitthemes.com/2021/01/26/">
                            December 6, 2020                        </a>
                                    </div>
            </div>
                    <div class="media post_item post-16517 post type-post status-publish format-standard has-post-thumbnail hentry category-droitthemes tag-macbook">
                <a href="https://droitthemes.com/4-things-you-need-to-build-an-effective-web-presence/">
                    <img width="85" height="70" src="https://droitthemes.com/wp-content/uploads/2020/11/4-Things-You-Need-to-Build-an-Effective-Web-Presence-85x70.png" class="media-object wp-post-image" alt="4 Things You Need to Build an Effective Web Presence" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/2020/11/4-Things-You-Need-to-Build-an-Effective-Web-Presence-85x70.png 85w, https://droitthemes.com/wp-content/uploads/2020/11/4-Things-You-Need-to-Build-an-Effective-Web-Presence-540x450.png 540w" sizes="(max-width: 85px) 100vw, 85px" />                </a>
                <div class="media-body">
                    <a href="https://droitthemes.com/4-things-you-need-to-build-an-effective-web-presence/" title="4 Things You Need to Build an Effective Web Presence">
                        <h5> 4 Things You Need to Build... </h5>
                    </a>
                                            <a class="entry_post_info" href="https://droitthemes.com/2021/01/26/">
                            November 24, 2020                        </a>
                                    </div>
            </div>
                    <div class="media post_item post-16517 post type-post status-publish format-standard has-post-thumbnail hentry category-droitthemes tag-macbook">
                <a href="https://droitthemes.com/10-best-ecommerce-platforms/">
                    <img width="85" height="70" src="https://droitthemes.com/wp-content/uploads/2020/10/Best-Ecommerce-Platforms-85x70.png" class="media-object wp-post-image" alt="Best Ecommerce Platforms" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/2020/10/Best-Ecommerce-Platforms-85x70.png 85w, https://droitthemes.com/wp-content/uploads/2020/10/Best-Ecommerce-Platforms-540x450.png 540w" sizes="(max-width: 85px) 100vw, 85px" />                </a>
                <div class="media-body">
                    <a href="https://droitthemes.com/10-best-ecommerce-platforms/" title="9+ Best Ecommerce Platforms for 2021">
                        <h5> 9+ Best Ecommerce Platforms for 2021 </h5>
                    </a>
                                            <a class="entry_post_info" href="https://droitthemes.com/2021/01/26/">
                            November 23, 2020                        </a>
                                    </div>
            </div>
        
		</div><div id="categories-3" class="widget sidebar_widget widget_categories"><h3 class="widget_title">Categories</h3> 
			<ul>
					<li class="cat-item cat-item-108"><a href="https://droitthemes.com/category/digital-marketing/">Digital Marketing</a>
</li>
	<li class="cat-item cat-item-434"><a href="https://droitthemes.com/category/domain/">Domain</a>
</li>
	<li class="cat-item cat-item-1"><a href="https://droitthemes.com/category/droitthemes/">DroitThemes</a>
</li>
	<li class="cat-item cat-item-135"><a href="https://droitthemes.com/category/hosting/">Hosting</a>
</li>
	<li class="cat-item cat-item-261"><a href="https://droitthemes.com/category/resource/">Resource</a>
</li>
	<li class="cat-item cat-item-123"><a href="https://droitthemes.com/category/saas/">SAAS</a>
</li>
	<li class="cat-item cat-item-4"><a href="https://droitthemes.com/category/sassland/">Sassland</a>
</li>
	<li class="cat-item cat-item-283"><a href="https://droitthemes.com/category/tech-support/">Tech Support</a>
</li>
	<li class="cat-item cat-item-124"><a href="https://droitthemes.com/category/web-design/">Web Design</a>
</li>
	<li class="cat-item cat-item-5"><a href="https://droitthemes.com/category/wordpress/">WordPress</a>
</li>
	<li class="cat-item cat-item-122"><a href="https://droitthemes.com/category/wordpress-plugin/">WordPress Plugin</a>
</li>
	<li class="cat-item cat-item-6"><a href="https://droitthemes.com/category/wordpress-theme/">WordPress Theme</a>
</li>
			</ul>

			</div>    </div>
</div>        </div>
    </div>
</section>


<footer class="footer_area">
    <img class="f_shadow_logo" src="http://droitthemes.com/wp-content/themes/dthemes/assets/img/footer_site_logo_gray.png" alt="DroitThemes">
    <div class="container">
        <div class="footer_top">
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="f_widget about_widget">
                                                    <a href="https://droitthemes.com/" class="f_logo">
                                <img src="https://droitthemes.com/wp-content/themes/dthemes/assets/img//f_logo.png" alt="DroitThemes">
                            </a>
                                                <p>Home of unique and easily customizable WordPress themes.</p>
                        <div class="f_social_icon">
                                        <a href="https://www.facebook.com/DroitThemes"><i class="social_facebook" aria-hidden="true"></i></a>
    
            <a href="https://twitter.com/droitthemes"><i class="social_twitter" aria-hidden="true"></i></a>
    
            <a href="https://www.instagram.com/droitthemes/"><i class="social_instagram" aria-hidden="true"></i></a>
    
            <a href="https://www.linkedin.com/company/droitthemes"><i class="social_linkedin" aria-hidden="true"></i></a>
    
            <a href="https://www.youtube.com/c/DroitThemes/"><i class="social_youtube" aria-hidden="true"></i></a>
    
    
                            </div>
                    </div>
                </div>
                                    <div class="col-lg-2 col-sm-6">
                        <div class="f_widget link_widget">
                                                            <h3 class="f_title">Company </h3>
                                                        <ul class="list-unstyled">
 	<li><a href="https://droitthemes.com/about-us/">About Us</a></li>
 	<li><a href="https://droitthemes.com/contact/">Contact</a></li>
 	<li><a href="https://droitthemes.com/licensing/">Licensing</a></li>
 	<li><a href="https://droitthemes.com/support-policy">Support Policy</a></li>
 	<li><a class="row-title" href="https://droitthemes.com/write-for-us/" aria-label="“Write For US” (Edit)">Write For US</a></li>
 	<li><a href="https://droitthemes.com/affiliate-program/">Affiliate Program</a></li>
</ul>                        </div>
                    </div>
                                
                
                                    <div class="col-lg-2 col-sm-6">
                        <div class="f_widget link_widget">
                                                            <h3 class="f_title">Resources</h3>
                                                        <ul class="list-unstyled">
 	<li><a href="https://droitthemes.com/droit-elementor-addons/" target="_blank" rel="noopener">Droit Addons</a></li>
 	<li><a href="https://droitthemes.com/category/domain/" target="_blank" rel="noopener">Domains</a></li>
 	<li><a href="https://droitthemes.com/category/hosting/" target="_blank" rel="noopener">Hostings</a></li>
 	<li><a href="https://droitthemes.com/blog/">Our Blog</a></li>
</ul>                        </div>
                    </div>
                                

                <div class="col-lg-4 col-sm-6">
                    <div class="f_widget product_widget pl-lg-5">
                                                    <h3 class="f_title"> Our Products </h3>
                                                <ul class="list-unstyled">
                                                                <li>
                                        <a href="https://droitthemes.com/products/servkar-vehicle-servicing-maintenace-wp-theme/" title="ServKar &#8211; Vehicle Servicing WP Theme">
                                            <img width="150" height="150" src="https://droitthemes.com/wp-content/uploads/edd/2020/11/servkar-1.png" class="attachment-full size-full" alt="servkar logo" loading="lazy" srcset="https://droitthemes.com/wp-content/uploads/edd/2020/11/servkar-1.png 150w, https://droitthemes.com/wp-content/uploads/edd/2020/11/servkar-1-128x128.png 128w" sizes="(max-width: 150px) 100vw, 150px" />ServKar                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="https://droitthemes.com/products/chaz-wordpress-theme/" title="Chaz &#8211; MultiPurpose WP Theme">
                                            <img src="https://droitthemes.com/wp-content/uploads/2020/08/chaz-logo.svg" class="attachment-full size-full" alt="chaz logo" loading="lazy" height="219.3" width="219.3" />Chaz                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="https://droitthemes.com/products/seon-wordpress-theme/" title="Seon &#8211; Digital Marketing WP Theme">
                                            <img src="https://droitthemes.com/wp-content/uploads/2020/08/seon-logo.svg" class="attachment-full size-full" alt="seon-logo" loading="lazy" height="200" width="200" />Seon                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="https://droitthemes.com/products/kitbe-wordpress-theme/" title="Kitbe &#8211; Digital Agency WP Theme">
                                            <img src="https://droitthemes.com/wp-content/uploads/2020/08/kitbe-logo.svg" class="attachment-full size-full" alt="kitbe logo" loading="lazy" height="200" width="200" />Kitbe                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="https://droitthemes.com/products/darkel-wordpress-theme/" title="Darkel &#8211; Dark WP Theme For Business">
                                            <img src="https://droitthemes.com/wp-content/uploads/2020/07/darkel.svg" class="attachment-full size-full" alt="Darkel logo" loading="lazy" height="200" width="200" />Darkel                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="https://droitthemes.com/products/varsity-education-wordpress-theme/" title="Varsity – Education WordPress Theme">
                                            <img src="https://droitthemes.com/wp-content/uploads/2020/07/Education.svg" class="attachment-full size-full" alt="Logo of Varsity" loading="lazy" height="200" width="200" />Varsity                                        </a>
                                    </li>
                                                            </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer_bottom">
            <div class="row">
                <div class="col-md-6">
                    <p>© 2016-2021 <a href="//droitthemes.com">DroitThemes</a>. All rights reserved</p>
                </div>
                <div class="col-md-6">
                    <ul class="foot-btm-menu">
                        <li><a href="https://droitthemes.com/privacy-policy/"> Privacy </a></li>
                        <li><a href="https://droitthemes.com/terms-and-conditions/"> Terms </a></li>
                        <li><a href="https://droitthemes.com/refund-policy/"> Refund Policy﻿ </a></li>
                    </ul>
                    <!--
                        <ul class="card_list list-unstyled">
                            <li> <img src="/icons/img_1.png" alt="visa card icon"> </li>
                            <li> <img src="/icons/img_2.png" alt="master card icon"> </li>
                            <li> <img src="/icons/img_3.png" alt="credit card icon"> </li>
                            <li> <img src="/icons/img_4.png" alt="credit card icon"> </li>
                        </ul>
                    -->                </div>
            </div>
        </div>
    </div>
</footer>

</div> <!-- Body wrapper -->

<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content login_popup">
            <div class="modal-header text-center">
                                    <a href="https://droitthemes.com/" class="brand-logo">
                        <img src="https://droitthemes.com/wp-content/themes/dthemes/assets/img/small_logo.png" srcset="https://droitthemes.com/wp-content/themes/dthemes/assets/img/small_logo@2x.png 2x" alt="DroitThemes">
                    </a>
                                <h5>Login your account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="icon-cross"></i>
                </button>
            </div>
            <div class="modal-body text-center">
                <form action="https://droitthemes.com/wp-login.php" name="registerform" id="registerform" method="post" class="login_form">
                    <div class="form-group email">
                        <input name="log" type="text" class="form-control login-email" placeholder="User name">
                    </div>
                    <!--//form-group-->
                    <div class="form-group password">
                        <input id="user_pass" name="pwd" type="password" class="form-control login-password" placeholder="Password">
                        <div class="extra">
                            <div class="checkbox remember">
                                <input id="rememder-me" type="checkbox">
                                <label for="rememder-me"> Remember me </label>
                            </div>
                            <!--//check-box-->
                            <a href="#" class="forgotten_password" id="resetpass-link" data-toggle="modal" data-target="#resetpass-modal">Lost password?</a>
                        </div>
                        <!--//extra-->
                    </div>
                    <!--//form-group-->
                    <button type="submit" name="submit" class="btn theme_btn menu_btn">Login account</button>
                </form>
                <div class="option_container">
                    Dont have an account?<a class="signup-link" id="signup-link" href="#">Create account</a>
                </div>
            </div>
        </div>
    </div>
</div><div class="modal fade" id="signup-modal" tabindex="-2" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content login_popup">
            <div class="modal-header text-center">
                                    <a href="https://droitthemes.com/" class="brand-logo">
                        <img src="https://droitthemes.com/wp-content/themes/dthemes/assets/img/small_logo.png" srcset="https://droitthemes.com/wp-content/themes/dthemes/assets/img/small_logo@2x.png 2x" alt="DroitThemes">
                    </a>
                                <h5>Create your account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="icon-cross"></i>
                </button>
            </div>
            <div class="modal-body text-center">
                    <div id="reg-form-validation-messages"> </div>
    <form id="register" class="ajax-auth login_form registerform"  action="#" method="post" data-url="https://droitthemes.com/wp-admin/admin-ajax.php">
        <input type="hidden" id="regsecurity" name="regsecurity" value="30fa679f04" /><input type="hidden" name="_wp_http_referer" value="/html/saasland/saasland-rtl/js/comming-soon.js" />        <div class="form-group">
            <input name="username" id="username" type="text" class="form-control" placeholder="User name" value="">
            <input name="FNAME" type="hidden" value="">
        </div>
        <div class="form-group">
            <input name="email" id="email" type="email" class="form-control" placeholder="Email address" value="">
            <input name="EMAIL" type="hidden" value="">
        </div>
        <!--//form-group-->
        <div class="form-group password">
            <input name="password" id="password" type="password" class="form-control signup-password" placeholder="Password" value="">
        </div>
        <!--//form-group-->
       <div class="g-recaptcha" data-sitekey="6LeUWb0ZAAAAAKrGVepMGnklN1JR7La6eMG17YtP"></div>
        <button type="submit" name="submit" class="btn theme_btn menu_btn">Create account</button>
        <input type="hidden" id="submit_et_form" name="submit_et_form" value="406634921e" /><input type="hidden" name="_wp_http_referer" value="/html/saasland/saasland-rtl/js/comming-soon.js" />    </form>
                    <div class="option_container">
                    Already have an account?<a class="signup-link" id="login-link" href="#">Login</a>
                </div>
            </div>
        </div>
    </div>
</div><div class="modal fade" id="resetpass-modal" tabindex="-2" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content login_popup">
            <div class="modal-header text-center">
                                    <a href="https://droitthemes.com/" class="brand-logo">
                        <img src="https://droitthemes.com/wp-content/themes/dthemes/assets/img/small_logo.png" srcset="https://droitthemes.com/wp-content/themes/dthemes/assets/img/small_logo@2x.png 2x" alt="DroitThemes">
                    </a>
                                <h5>Recover Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="icon-cross"></i>
                </button>
            </div>
            <div class="modal-body text-center">
                <form name="lostpasswordform" id="lostpasswordform" action="https://droitthemes.com/wp-login.php?action=lostpassword" method="post" class="login_form">
                    <div class="form-group">
                        <input name="user_login" id="user_login" type="text" class="form-control" placeholder="Username or Email">
                    </div>
                    <button type="submit" name="wp-submit" id="wp-submit" class="btn theme_btn menu_btn" data-toggle="modal" data-target="#resetpass-confirm-modal">Reset Password</button>
                </form>
                <div class="option_container">
                    Wanna login to your account?<a class="signup-link" id="back-to-login-link" href="#">Login</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="edd-free-downloads-modal-wrapper edd-free-downloads"><span class="edd-loading"></span><div id="edd-free-downloads-modal" style="display:none"></div></div><link rel='stylesheet' id='mailpoet_public-css'  href='http://droitthemes.com/wp-content/plugins/mailpoet/assets/dist/css/mailpoet-public.c040faed.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='mailpoet_custom_fonts_css-css'  href='https://fonts.googleapis.com/css?display=swap&family=Abril+FatFace%3A400%2C400i%2C700%2C700i%7CAlegreya%3A400%2C400i%2C700%2C700i%7CAlegreya+Sans%3A400%2C400i%2C700%2C700i%7CAmatic+SC%3A400%2C400i%2C700%2C700i%7CAnonymous+Pro%3A400%2C400i%2C700%2C700i%7CArchitects+Daughter%3A400%2C400i%2C700%2C700i%7CArchivo%3A400%2C400i%2C700%2C700i%7CArchivo+Narrow%3A400%2C400i%2C700%2C700i%7CAsap%3A400%2C400i%2C700%2C700i%7CBarlow%3A400%2C400i%2C700%2C700i%7CBioRhyme%3A400%2C400i%2C700%2C700i%7CBonbon%3A400%2C400i%2C700%2C700i%7CCabin%3A400%2C400i%2C700%2C700i%7CCairo%3A400%2C400i%2C700%2C700i%7CCardo%3A400%2C400i%2C700%2C700i%7CChivo%3A400%2C400i%2C700%2C700i%7CConcert+One%3A400%2C400i%2C700%2C700i%7CCormorant%3A400%2C400i%2C700%2C700i%7CCrimson+Text%3A400%2C400i%2C700%2C700i%7CEczar%3A400%2C400i%2C700%2C700i%7CExo+2%3A400%2C400i%2C700%2C700i%7CFira+Sans%3A400%2C400i%2C700%2C700i%7CFjalla+One%3A400%2C400i%2C700%2C700i%7CFrank+Ruhl+Libre%3A400%2C400i%2C700%2C700i%7CGreat+Vibes%3A400%2C400i%2C700%2C700i%7CHeebo%3A400%2C400i%2C700%2C700i%7CIBM+Plex%3A400%2C400i%2C700%2C700i%7CInconsolata%3A400%2C400i%2C700%2C700i%7CIndie+Flower%3A400%2C400i%2C700%2C700i%7CInknut+Antiqua%3A400%2C400i%2C700%2C700i%7CInter%3A400%2C400i%2C700%2C700i%7CKarla%3A400%2C400i%2C700%2C700i%7CLibre+Baskerville%3A400%2C400i%2C700%2C700i%7CLibre+Franklin%3A400%2C400i%2C700%2C700i%7CMontserrat%3A400%2C400i%2C700%2C700i%7CNeuton%3A400%2C400i%2C700%2C700i%7CNotable%3A400%2C400i%2C700%2C700i%7CNothing+You+Could+Do%3A400%2C400i%2C700%2C700i%7CNoto+Sans%3A400%2C400i%2C700%2C700i%7CNunito%3A400%2C400i%2C700%2C700i%7COld+Standard+TT%3A400%2C400i%2C700%2C700i%7COxygen%3A400%2C400i%2C700%2C700i%7CPacifico%3A400%2C400i%2C700%2C700i%7CPoppins%3A400%2C400i%2C700%2C700i%7CProza+Libre%3A400%2C400i%2C700%2C700i%7CPT+Sans%3A400%2C400i%2C700%2C700i%7CPT+Serif%3A400%2C400i%2C700%2C700i%7CRakkas%3A400%2C400i%2C700%2C700i%7CReenie+Beanie%3A400%2C400i%2C700%2C700i%7CRoboto+Slab%3A400%2C400i%2C700%2C700i%7CRopa+Sans%3A400%2C400i%2C700%2C700i%7CRubik%3A400%2C400i%2C700%2C700i%7CShadows+Into+Light%3A400%2C400i%2C700%2C700i%7CSpace+Mono%3A400%2C400i%2C700%2C700i%7CSpectral%3A400%2C400i%2C700%2C700i%7CSue+Ellen+Francisco%3A400%2C400i%2C700%2C700i%7CTitillium+Web%3A400%2C400i%2C700%2C700i%7CUbuntu%3A400%2C400i%2C700%2C700i%7CVarela%3A400%2C400i%2C700%2C700i%7CVollkorn%3A400%2C400i%2C700%2C700i%7CWork+Sans%3A400%2C400i%2C700%2C700i%7CYatra+One%3A400%2C400i%2C700%2C700i&#038;ver=5.6.2' type='text/css' media='all' />
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/masonry.min.js?ver=4.2.2' id='masonry-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/clipboard.min.js?ver=5.6.2' id='clipboard-js'></script>
<script type='text/javascript' id='betterdocs-js-extra'>
/* <![CDATA[ */
var betterdocspublic = {"ajax_url":"https:\/\/droitthemes.com\/wp-admin\/admin-ajax.php","post_id":"16517","copy_text":"Copied","sticky_toc_offset":"100","nonce":"a95633d8c6"};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/betterdocs/public/js/betterdocs-public.js?ver=1.0.0' id='betterdocs-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/betterdocs/public/js/simplebar.js?ver=1.0.0' id='simplebar-js'></script>
<script type='text/javascript' id='betterdocs-pro-js-extra'>
/* <![CDATA[ */
var betterdocs = {"FEEDBACK":{"DISPLAY":true,"TEXT":"How did you feel?","SUCCESS":"Thanks for your feedback","URL":"https:\/\/droitthemes.com?rest_route=\/betterdocs\/feedback"}};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/betterdocs-pro/public/js/betterdocs-pro-public.js?ver=1.3.7' id='betterdocs-pro-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4' id='wp-polyfill-js'></script>
<script   type='text/javascript' id='wp-polyfill-js-after'>
( 'fetch' in window ) || document.write( '<script   src="http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script   src="http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script   src="http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script   src="http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?ver=3.6.4"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script   src="http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script   src="http://droitthemes.com/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>' );
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/dist/i18n.min.js?ver=ac389435e7fd4ded01cf603f3aaba6a6' id='wp-i18n-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/dist/vendor/lodash.min.js?ver=4.17.19' id='lodash-js'></script>
<script   type='text/javascript' id='lodash-js-after'>
window.lodash = _.noConflict();
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/dist/url.min.js?ver=98645f0502e5ed8dadffd161e39072d2' id='wp-url-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/dist/hooks.min.js?ver=84b89ab09cbfb4469f02183611cc0939' id='wp-hooks-js'></script>
<script   type='text/javascript' id='wp-api-fetch-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/dist/api-fetch.min.js?ver=4dec825c071b87c57f687eb90f7c23c3' id='wp-api-fetch-js'></script>
<script   type='text/javascript' id='wp-api-fetch-js-after'>
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://droitthemes.com/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "4a343a61d9" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://droitthemes.com/wp-admin/admin-ajax.php?action=rest-nonce";
</script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"cached":"1"};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.4' id='contact-form-7-js'></script>
<script type='text/javascript' id='edd-ajax-js-extra'>
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/droitthemes.com\/wp-admin\/admin-ajax.php","position_in_cart":"","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"smartpay_paddle","redirect_to_checkout":"1","checkout_page":"https:\/\/droitthemes.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.9.26' id='edd-ajax-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/edd-free-downloads/assets/js/isMobile.min.js' id='edd-free-downloads-mobile-js'></script>
<script type='text/javascript' id='edd-free-downloads-js-extra'>
/* <![CDATA[ */
var edd_free_downloads_vars = {"close_button":"box","user_registration":"false","require_name":"false","download_loading":"Please Wait... ","download_label":"Download Now","modal_download_label":"Download Now","has_ajax":"1","ajaxurl":"https:\/\/droitthemes.com\/wp-admin\/admin-ajax.php","mobile_url":"\/html\/saasland\/saasland-rtl\/js\/comming-soon.js?edd-free-download=true","form_class":"edd_purchase_submit_wrapper","bypass_logged_in":"false","is_download":"false","edd_is_mobile":"","success_page":"https:\/\/droitthemes.com\/checkout\/purchase-confirmation\/","guest_checkout_disabled":"","email_verification":"1","on_complete_handler":"default","on_complete_delay":"2000"};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/edd-free-downloads/assets/js/edd-free-downloads.min.js?ver=2.3.9' id='edd-free-downloads-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/bootstrap/js/popper.min.js?ver=1.0.0' id='popper-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/bootstrap/js/bootstrap.min.js?ver=4.4.1' id='bootstrap-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/magnify-pop/jquery.magnific-popup.min.js?ver=1.1.0' id='magnific-popup-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/wow/wow.min.js?ver=1.1.3' id='wow-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/js/scrollspy.js?ver=0.1.2' id='scrollspy-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/scroll/jquery.mCustomScrollbar.concat.min.js?ver=3.1.5' id='mCustomScrollbar-js'></script>
<script   type='text/javascript' src='https://www.google.com/recaptcha/api.js?ver=1.0.0' id='dt-recaptcha-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/js/custom.js?ver=1.0.0' id='dt-custom-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/js/wp-custom.js?ver=1.0.0' id='dt-wp-custom-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/themes/dthemes/assets/vendors/countdown/countdown.js?ver=1.0.0' id='countdown-js-js'></script>
<script   type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6LfVM2saAAAAAOSQxu6B1jHMZdqvrtL65kejySX7&#038;ver=3.0' id='google-recaptcha-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6LfVM2saAAAAAOSQxu6B1jHMZdqvrtL65kejySX7","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.4' id='wpcf7-recaptcha-js'></script>
<script   type='text/javascript' src='http://droitthemes.com/wp-includes/js/wp-embed.min.js?ver=5.6.2' id='wp-embed-js'></script>
<script type='text/javascript' id='mailpoet_public-js-extra'>
/* <![CDATA[ */
var MailPoetForm = {"ajax_url":"https:\/\/droitthemes.com\/wp-admin\/admin-ajax.php","is_rtl":""};
/* ]]> */
</script>
<script   type='text/javascript' src='http://droitthemes.com/wp-content/plugins/mailpoet/assets/dist/js/public.d4d8a8c5.js?ver=3.60.2' id='mailpoet_public-js'></script>
<script   type='text/javascript' id='mailpoet_public-js-after'>
function initMailpoetTranslation() {
  if (typeof MailPoet !== 'undefined') {
    MailPoet.I18n.add('ajaxFailedErrorMessage', 'An error has happened while performing a request, please try again later.')
  } else {
    setTimeout(initMailpoetTranslation, 250);
  }
}
setTimeout(initMailpoetTranslation, 250);
</script>
</body>
</html> 

<!-- Page generated by LiteSpeed Cache 3.6.2 on 2021-03-06 08:19:08 -->